Untuk Menjalankan Tailwind, berikut perintah yang dapat kalian jalankan pada terminal masing masing

Perintah :
npx tailwindcss -i ./src/assets/css/input.css -o ./src/assets/css/output.css --watch